import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*;

def Message processData(Message message) {
               
                // get a map of iflow properties
                def map = message.getProperties();
                def ex = map.get("CamelExceptionCaught"); 
               
if (ex!=null) {
                                // a mapping failure throws an instance of com.sap.xi.mapping.camel.XiMappingException
                        if (ex.getClass().getCanonicalName().equals("com.sap.xi.mapping.camel.XiMappingException")) {
                                               
                                       //logic for error field fetching
                                 String[] strarray= ex.toString().split("/");
                                 int size = strarray.length;
                                 def last= strarray[size-1];
                                 int index = last.indexOf(".");
                                 def field = last.substring(0, index);
                 
                                message.setBody("{\"message\": \"Error occured due to missing of a Field!!!\",\"Log ID\": \""
                                   +map.get("SAP_MessageProcessingLogID")+"\",\"Missing Field\": \""+field+"\"}");
                                   
                               // message.setHeader("Content-Type","application/json");  
                 
                                message.setHeader("CamelHttpResponseCode",400);
                                message.setHeader("CamelHttpResponseText","Bad Request");
                               
                                }
else  {
                                     
                                // copy the value of http error code (i.e. 500) to a property
                                message.setHeader("CamelHttpResponseCode",404);

                                // copy the value of http error text (i.e. "Internal Server Error") to a property
                                message.setHeader("CamelHttpResponseText","Resource Not Found");
                                               
                                message.setBody("{\"message\": \"Error Occured due to other reasons\",\"Log ID\": \""
                                   +map.get("SAP_MessageProcessingLogID")+"\"}");
                                   
                                }
                               
                }
               
                return message;
}