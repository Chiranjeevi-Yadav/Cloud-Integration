import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
def body = message.getBody(java.lang.String) as String;
//body=body.replace('rfc','ns1')
body=body.replace('rfc:ZRFI_HYB_PYMT.Response','ns1:ZRFI_HYB_PYMTResponse')
body=body.replace('xmlns:rfc="urn:sap-com:document:sap:rfc:functions','xmlns:ns1="urn:sap-com:document:sap:rfc:functions')
message.setBody(body);
return message;
}  